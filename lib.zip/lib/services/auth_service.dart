import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

class AuthService {
  static const String _tokenKey = 'auth_token';
  static const String _userKey = 'user_data';

  // Singleton pattern
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  String? _token;
  Map<String, dynamic>? _user;

  // Getters
  String? get token => _token;
  Map<String, dynamic>? get user => _user;
  bool get isLoggedIn => _token != null;

  // Initialize - load token from storage
  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _token = prefs.getString(_tokenKey);
      final userJson = prefs.getString(_userKey);
      if (userJson != null) {
        _user = json.decode(userJson);
      }
    } catch (e) {
      // Clear corrupted data
      await logout();
    }
  }

  // Login
  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('${AppConfig.authEndpoint}/login'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'password': password,
        }),
      ).timeout(Duration(seconds: AppConfig.requestTimeoutSeconds));

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['success'] == true) {
        // Save token and user data
        _token = data['data']['token'];
        _user = data['data']['user'];

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_tokenKey, _token!);
        await prefs.setString(_userKey, json.encode(_user!));

        return {'success': true, 'message': data['message']};
      } else {
        return {'success': false, 'message': data['message'] ?? 'Đăng nhập thất bại'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  // Register
  Future<Map<String, dynamic>> register({
    required String email,
    required String password,
    required String fullName,
    required String phone,
    String role = 'user',
  }) async {
    try {
      final response = await http.post(
        Uri.parse('${AppConfig.authEndpoint}/register'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'password': password,
          'full_name': fullName,
          'phone': phone,
          'role': role,
        }),
      ).timeout(Duration(seconds: AppConfig.requestTimeoutSeconds));

      final data = json.decode(response.body);

      if (response.statusCode == 201 && data['success'] == true) {
        // Auto login after register
        return await login(email, password);
      } else {
        return {'success': false, 'message': data['message'] ?? 'Đăng ký thất bại'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  // Logout
  Future<void> logout() async {
    _token = null;
    _user = null;

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_tokenKey);
      await prefs.remove(_userKey);
    } catch (e) {
      // Ignore storage errors during logout
    }
  }

  // Get headers with auth token
  Map<String, String> getAuthHeaders() {
    return {
      'Content-Type': 'application/json',
      if (_token != null) 'Authorization': 'Bearer $_token',
    };
  }

  // Make authenticated HTTP request - FIX CRITICAL BUG
  Future<http.Response> authenticatedRequest({
    required String method,
    required String endpoint,
    Map<String, dynamic>? body,
  }) async {
    final uri = Uri.parse(endpoint);
    final headers = getAuthHeaders();
    final bodyString = body != null ? json.encode(body) : null;

    try {
      switch (method.toUpperCase()) {
        case 'GET':
          return await http.get(uri, headers: headers);
        case 'POST':
          return await http.post(uri, headers: headers, body: bodyString);
        case 'PATCH':
        // FIX: Use correct PATCH method instead of POST
          return await http.patch(uri, headers: headers, body: bodyString);
        case 'PUT':
          return await http.put(uri, headers: headers, body: bodyString);
        case 'DELETE':
          return await http.delete(uri, headers: headers);
        default:
          throw Exception('Unsupported HTTP method: $method');
      }
    } catch (e) {
      // Re-throw with more context
      throw Exception('HTTP $method request failed: $e');
    }
  }

  // Check if token is still valid
  Future<bool> isTokenValid() async {
    if (_token == null) return false;

    try {
      final response = await authenticatedRequest(
        method: 'GET',
        endpoint: '${AppConfig.userEndpoint}/profile',
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // Refresh user data
  Future<void> refreshUser() async {
    if (_token == null) return;

    try {
      final response = await authenticatedRequest(
        method: 'GET',
        endpoint: '${AppConfig.userEndpoint}/profile',
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          _user = data['user'];

          final prefs = await SharedPreferences.getInstance();
          await prefs.setString(_userKey, json.encode(_user!));
        }
      }
    } catch (e) {
      // Ignore refresh errors
    }
  }
}