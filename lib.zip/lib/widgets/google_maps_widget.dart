import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../services/location_service.dart';

class GoogleMapsWidget extends StatefulWidget {
  final LatLng? pickup;
  final LatLng? destination;
  final VoidCallback? onMapTap;
  final Function(LatLng)? onLocationSelected;

  const GoogleMapsWidget({
    super.key,
    this.pickup,
    this.destination,
    this.onMapTap,
    this.onLocationSelected,
  });

  @override
  State<GoogleMapsWidget> createState() => _GoogleMapsWidgetState();
}

class _GoogleMapsWidgetState extends State<GoogleMapsWidget> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};

  // Default location (Hanoi)
  static const LatLng _defaultLocation = LatLng(21.0285, 105.8542);

  @override
  void initState() {
    super.initState();
    _updateMarkers();
  }

  @override
  void didUpdateWidget(GoogleMapsWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.pickup != widget.pickup ||
        oldWidget.destination != widget.destination) {
      _updateMarkers();
    }
  }

  void _updateMarkers() {
    _markers.clear();

    if (widget.pickup != null) {
      _markers.add(
        Marker(
          markerId: const MarkerId('pickup'),
          position: widget.pickup!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          infoWindow: const InfoWindow(
            title: 'Điểm đón',
            snippet: 'Vị trí đón khách',
          ),
        ),
      );
    }

    if (widget.destination != null) {
      _markers.add(
        Marker(
          markerId: const MarkerId('destination'),
          position: widget.destination!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: const InfoWindow(
            title: 'Điểm đến',
            snippet: 'Điểm đến của chuyến đi',
          ),
        ),
      );
    }

    if (widget.pickup != null && widget.destination != null) {
      _addRoute();
    }

    if (mounted) setState(() {});
  }

  void _addRoute() {
    _polylines.add(
      Polyline(
        polylineId: const PolylineId('route'),
        points: [widget.pickup!, widget.destination!],
        color: Colors.blue,
        width: 4,
        patterns: [PatternItem.dash(20), PatternItem.gap(10)],
      ),
    );
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    _fitMarkersInView();
  }

  void _fitMarkersInView() {
    if (_mapController == null) return;

    if (widget.pickup != null && widget.destination != null) {
      LatLngBounds bounds = LatLngBounds(
        southwest: LatLng(
          widget.pickup!.latitude < widget.destination!.latitude
              ? widget.pickup!.latitude
              : widget.destination!.latitude,
          widget.pickup!.longitude < widget.destination!.longitude
              ? widget.pickup!.longitude
              : widget.destination!.longitude,
        ),
        northeast: LatLng(
          widget.pickup!.latitude > widget.destination!.latitude
              ? widget.pickup!.latitude
              : widget.destination!.latitude,
          widget.pickup!.longitude > widget.destination!.longitude
              ? widget.pickup!.longitude
              : widget.destination!.longitude,
        ),
      );

      _mapController!.animateCamera(
        CameraUpdate.newLatLngBounds(bounds, 100),
      );
    } else if (widget.pickup != null) {
      _mapController!.animateCamera(
        CameraUpdate.newLatLngZoom(widget.pickup!, 15),
      );
    }
  }

  void _onTap(LatLng position) {
    widget.onLocationSelected?.call(position);
    widget.onMapTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<LocationService>(
      builder: (context, locationService, child) {
        LatLng initialPosition = _defaultLocation;

        // FIXED: Proper null check
        if (locationService.hasLocation) {
          final pos = locationService.currentPosition!;
          initialPosition = LatLng(pos.latitude, pos.longitude);
        }

        return Stack(
          children: [
            GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: widget.pickup ?? initialPosition,
                zoom: 15.0,
              ),
              markers: _markers,
              polylines: _polylines,
              onTap: _onTap,
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              mapToolbarEnabled: false,
              buildingsEnabled: true,
              trafficEnabled: false,
              mapType: MapType.normal,
            ),

            // Custom controls
            Positioned(
              top: 16,
              right: 16,
              child: Column(
                children: [
                  _buildMapButton(
                    icon: Icons.my_location,
                    onPressed: () async {
                      final success = await locationService.getCurrentLocation();
                      if (success && locationService.hasLocation) {
                        final pos = locationService.currentPosition!;
                        _mapController?.animateCamera(
                          CameraUpdate.newLatLngZoom(
                            LatLng(pos.latitude, pos.longitude),
                            16,
                          ),
                        );
                      } else if (locationService.errorMessage != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(locationService.errorMessage!),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildMapButton(
                    icon: Icons.zoom_in,
                    onPressed: () {
                      _mapController?.animateCamera(CameraUpdate.zoomIn());
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildMapButton(
                    icon: Icons.zoom_out,
                    onPressed: () {
                      _mapController?.animateCamera(CameraUpdate.zoomOut());
                    },
                  ),
                ],
              ),
            ),

            if (locationService.isLoading)
              const Center(
                child: CircularProgressIndicator(),
              ),
          ],
        );
      },
    );
  }

  Widget _buildMapButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon),
        onPressed: onPressed,
      ),
    );
  }
}