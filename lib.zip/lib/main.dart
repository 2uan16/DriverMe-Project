import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

// Import config
import 'config/app_theme.dart';

// Import services
import 'services/location_service.dart';
import 'services/socket_service.dart';
import 'services/auth_service.dart';

// Import screens
import 'screens/splash_screen.dart';
import 'screens/auth/role_selection_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/user/user_home_screen.dart';
import 'screens/driver/driver_home_screen.dart';
import 'screens/user/user_bookings_screen.dart';
import 'screens/user/point_to_point_booking_screen.dart';
import 'screens/user/hourly_booking_screen.dart';
import 'screens/driver/available_bookings_screen.dart';
import 'screens/driver/driver_bookings_screen.dart';
import 'screens/user/enhanced_booking_screen.dart';
import 'screens/user/map_booking_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize AuthService
  await AuthService().init();

  runApp(const DriverMeApp());
}

class AppConfig {
  static const String appName = 'DriverMe';
}

class DriverMeApp extends StatelessWidget {
  const DriverMeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LocationService()),
        ChangeNotifierProvider(create: (_) => SocketService()),
      ],
      child: MaterialApp.router(
        title: AppConfig.appName,
        theme: AppTheme.lightTheme,
        debugShowCheckedModeBanner: false,
        routerConfig: _router,
      ),
    );
  }
}

// Router configuration
final GoRouter _router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/role-selection',
      builder: (context, state) => const RoleSelectionScreen(),
    ),
    GoRoute(
      path: '/login-user',
      builder: (context, state) => const LoginScreen(role: 'user'),
    ),
    GoRoute(
      path: '/login-driver',
      builder: (context, state) => const LoginScreen(role: 'driver'),
    ),
    GoRoute(
      path: '/register-user',
      builder: (context, state) => const RegisterScreen(role: 'user'),
    ),
    GoRoute(
      path: '/register-driver',
      builder: (context, state) => const RegisterScreen(role: 'driver'),
    ),
    GoRoute(
      path: '/user-home',
      builder: (context, state) => const UserHomeScreen(),
    ),
    GoRoute(
      path: '/driver-home',
      builder: (context, state) => const DriverHomeScreen(),
    ),
    GoRoute(
      path: '/user/point-to-point-booking',
      builder: (context, state) => const PointToPointBookingScreen(),
    ),
    GoRoute(
      path: '/user/hourly-booking',
      builder: (context, state) => const HourlyBookingScreen(),
    ),
    GoRoute(
      path: '/bookings',
      builder: (context, state) => const UserBookingsScreen(),
    ),
    GoRoute(
      path: '/driver/available-bookings',
      builder: (context, state) => const AvailableBookingsScreen(),
    ),
    GoRoute(
      path: '/driver/my-bookings',
      builder: (context, state) => const DriverBookingsScreen(),
    ),
    GoRoute(
      path: '/user/enhanced-booking',
      builder: (context, state) => const EnhancedBookingScreen(),
    ),
    GoRoute(
      path: '/user/map-booking',
      builder: (context, state) => const MapBookingScreen(),
    ),
  ],
);