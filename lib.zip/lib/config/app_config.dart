class AppConfig {
  static const String baseUrl = 'http://10.0.2.2:3000/api';
  static const String authEndpoint = '$baseUrl/auth';
  static const String userEndpoint = '$baseUrl/users';
  static const String driverEndpoint = '$baseUrl/drivers';
  static const String bookingEndpoint = '$baseUrl/bookings';
  static const String adminEndpoint = '$baseUrl/admin';

  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';

  static const int requestTimeoutSeconds = 30;
  static const int minPasswordLength = 6;

  static const double defaultPadding = 16.0;
  static const double defaultBorderRadius = 12.0;
  static const double buttonHeight = 48.0;
}