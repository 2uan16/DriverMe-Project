class ApiKeys {
  ApiKeys._();
  static const String _computerIp = '192.168.1.133';

  static const List<String> _backendUrls = [
    'http://10.0.2.2:3000',
    'http://$_computerIp:3000',
  ];

  static String get backendBaseUrl => _backendUrls[0];
  static List<String> get allBackendUrls => _backendUrls;

  static const String mapboxAccessToken =
      'sk.eyJ1IjoiMnVhbjE2IiwiYSI6ImNtZ3JmNjF1YzFpbG8ybHIyeWxxa3oxM3kifQ._6OhCZ7xKGAJYHRzsxxWEg';

  static String get socketUrl => backendBaseUrl;
}
