import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:async';
import 'package:go_router/go_router.dart';
import '../../config/app_config.dart';
import '../../services/auth_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MapBookingScreen extends StatefulWidget {
  const MapBookingScreen({super.key});

  @override
  State<MapBookingScreen> createState() => _MapBookingScreenState();
}

class _MapBookingScreenState extends State<MapBookingScreen> {
  final AuthService _authService = AuthService();
  GoogleMapController? _mapController;
  Position? _currentPosition;
  String _pickupAddress = 'Đang xác định vị trí...';
  String _destinationAddress = '';

  final _destinationController = TextEditingController();
  List<Map<String, dynamic>> _searchResults = [];
  bool _isSearching = false;
  bool _showVehicleSelection = false;

  // Markers
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  // Vehicle categories
  final List<Map<String, dynamic>> _vehicleCategories = [
    {
      'category': 'Dòng xe phổ thông',
      'vehicles': [
        {
          'name': 'DriverMe Eco',
          'icon': '🚗',
          'basePrice': 12000,
          'pricePerKm': 12000,
          'description': 'Tiết kiệm, thân thiện môi trường',
          'capacity': 4,
          'eta': '3-5 phút',
        },
        {
          'name': 'DriverMe',
          'icon': '🚙',
          'basePrice': 15000,
          'pricePerKm': 15000,
          'description': 'Xe phổ thông 4 chỗ',
          'capacity': 4,
          'eta': '2-4 phút',
        },
      ]
    },
    {
      'category': 'Dòng xe trung cấp',
      'vehicles': [
        {
          'name': 'DriverMe Plus',
          'icon': '🚘',
          'basePrice': 20000,
          'pricePerKm': 20000,
          'description': 'Xe trung cấp, thoải mái hơn',
          'capacity': 4,
          'eta': '3-6 phút',
        },
        {
          'name': 'DriverMe 7',
          'icon': '🚐',
          'basePrice': 25000,
          'pricePerKm': 25000,
          'description': 'Xe 7 chỗ, phù hợp gia đình',
          'capacity': 7,
          'eta': '4-7 phút',
        },
      ]
    },
    {
      'category': 'Dòng xe cao cấp/hạng sang',
      'vehicles': [
        {
          'name': 'DriverMe Premium',
          'icon': '🏎️',
          'basePrice': 35000,
          'pricePerKm': 35000,
          'description': 'Xe cao cấp, dịch vụ VIP',
          'capacity': 4,
          'eta': '5-10 phút',
        },
        {
          'name': 'DriverMe Luxury',
          'icon': '🚗',
          'basePrice': 50000,
          'pricePerKm': 50000,
          'description': 'Xe hạng sang, phục vụ đẳng cấp',
          'capacity': 4,
          'eta': '7-12 phút',
        },
      ]
    },
    {
      'category': 'Dòng xe chuyên biệt',
      'vehicles': [
        {
          'name': 'DriverMe Bike',
          'icon': '🏍️',
          'basePrice': 8000,
          'pricePerKm': 8000,
          'description': 'Xe máy, di chuyển nhanh',
          'capacity': 2,
          'eta': '1-3 phút',
        },
        {
          'name': 'DriverMe Truck',
          'icon': '🚚',
          'basePrice': 30000,
          'pricePerKm': 30000,
          'description': 'Xe tải nhỏ, chở hàng',
          'capacity': 3,
          'eta': '10-15 phút',
        },
      ]
    },
  ];

  int _selectedVehicleIndex = 1; // Default: DriverMe
  LatLng? _destinationLatLng;
  double? _distance;
  double? _estimatedPrice;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  @override
  void dispose() {
    _destinationController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> _getCurrentLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showSnackBar('Vui lòng bật dịch vụ định vị');
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showSnackBar('Quyền truy cập vị trí bị từ chối');
          return;
        }
      }

      Position position = await Geolocator.getCurrentPosition();
      setState(() {
        _currentPosition = position;
      });

      // Get address from coordinates
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        setState(() {
          _pickupAddress = '${place.street}, ${place.subLocality}, ${place.locality}';
        });
      }

      // Add pickup marker
      _markers.add(
        Marker(
          markerId: const MarkerId('pickup'),
          position: LatLng(position.latitude, position.longitude),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          infoWindow: InfoWindow(title: 'Điểm đón', snippet: _pickupAddress),
        ),
      );

      // Move camera to current location
      _mapController?.animateCamera(
        CameraUpdate.newLatLngZoom(
          LatLng(position.latitude, position.longitude),
          15,
        ),
      );

      setState(() {});
    } catch (e) {
      _showSnackBar('Lỗi lấy vị trí: $e');
    }
  }

  Future<void> _searchPlaces(String query) async {
    if (query.isEmpty) {
      setState(() => _searchResults = []);
      return;
    }

    setState(() => _isSearching = true);

    try {
      // Use Geocoding to search places
      List<Location> locations = await locationFromAddress(query);

      if (locations.isNotEmpty) {
        List<Map<String, dynamic>> results = [];

        for (var location in locations.take(5)) {
          List<Placemark> placemarks = await placemarkFromCoordinates(
            location.latitude,
            location.longitude,
          );

          if (placemarks.isNotEmpty) {
            Placemark place = placemarks[0];
            results.add({
              'name': query,
              'address': '${place.street}, ${place.subLocality}, ${place.locality}',
              'latitude': location.latitude,
              'longitude': location.longitude,
            });
          }
        }

        setState(() {
          _searchResults = results;
        });
      }
    } catch (e) {
      print('Search error: $e');
    } finally {
      setState(() => _isSearching = false);
    }
  }

  void _selectDestination(Map<String, dynamic> place) {
    setState(() {
      _destinationAddress = place['address'];
      _destinationLatLng = LatLng(place['latitude'], place['longitude']);
      _searchResults = [];
      _destinationController.text = place['address'];
    });

    // Add destination marker
    _markers.removeWhere((m) => m.markerId.value == 'destination');
    _markers.add(
      Marker(
        markerId: const MarkerId('destination'),
        position: _destinationLatLng!,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow: InfoWindow(title: 'Điểm đến', snippet: _destinationAddress),
      ),
    );

    // Draw route
    _drawRoute();

    // Show vehicle selection
    setState(() => _showVehicleSelection = true);
  }

  Future<void> _drawRoute() async {
    if (_currentPosition == null || _destinationLatLng == null) return;

    // Calculate distance
    double distanceInMeters = Geolocator.distanceBetween(
      _currentPosition!.latitude,
      _currentPosition!.longitude,
      _destinationLatLng!.latitude,
      _destinationLatLng!.longitude,
    );

    setState(() {
      _distance = distanceInMeters / 1000; // Convert to km
    });

    // Simple straight line for demo (in production, use Directions API)
    _polylines.add(
      Polyline(
        polylineId: const PolylineId('route'),
        points: [
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          _destinationLatLng!,
        ],
        color: Colors.blue,
        width: 4,
      ),
    );

    // Calculate price
    _calculatePrice();

    // Fit bounds
    LatLngBounds bounds = LatLngBounds(
      southwest: LatLng(
        _currentPosition!.latitude < _destinationLatLng!.latitude
            ? _currentPosition!.latitude
            : _destinationLatLng!.latitude,
        _currentPosition!.longitude < _destinationLatLng!.longitude
            ? _currentPosition!.longitude
            : _destinationLatLng!.longitude,
      ),
      northeast: LatLng(
        _currentPosition!.latitude > _destinationLatLng!.latitude
            ? _currentPosition!.latitude
            : _destinationLatLng!.latitude,
        _currentPosition!.longitude > _destinationLatLng!.longitude
            ? _currentPosition!.longitude
            : _destinationLatLng!.longitude,
      ),
    );

    _mapController?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 100));
    setState(() {});
  }

  void _calculatePrice() {
    if (_distance == null) return;

    final vehicle = _getAllVehicles()[_selectedVehicleIndex];
    final pricePerKm = vehicle['pricePerKm'] as int;

    setState(() {
      _estimatedPrice = (_distance! * pricePerKm) + 10000; // + booking fee
    });
  }

  List<Map<String, dynamic>> _getAllVehicles() {
    List<Map<String, dynamic>> allVehicles = [];
    for (var category in _vehicleCategories) {
      allVehicles.addAll(category['vehicles']);
    }
    return allVehicles;
  }

  Future<void> _createBooking() async {
    if (_currentPosition == null || _destinationLatLng == null) {
      _showSnackBar('Vui lòng chọn điểm đến');
      return;
    }

    setState(() => _isSearching = true);

    try {
      final vehicle = _getAllVehicles()[_selectedVehicleIndex];

      final res = await _authService.authenticatedRequest(
        method: 'POST',
        endpoint: AppConfig.bookingEndpoint,
        body: {
          'pickup_address': _pickupAddress,
          'pickup_latitude': _currentPosition!.latitude,
          'pickup_longitude': _currentPosition!.longitude,
          'destination_address': _destinationAddress,
          'destination_latitude': _destinationLatLng!.latitude,
          'destination_longitude': _destinationLatLng!.longitude,
          'service_type': 'point_to_point',
          'vehicle_type': vehicle['name'],
          'estimated_price': _estimatedPrice?.toInt(),
          'distance_km': _distance,
        },
      );

      if (!mounted) return;

      final data = json.decode(res.body);

      if (res.statusCode >= 200 && res.statusCode < 300 && data['success'] == true) {
        _showSnackBar(data['message'] ?? 'Đặt chuyến thành công!', isError: false);
        context.go('/bookings');
      } else {
        _showSnackBar(data['message'] ?? 'Đặt chuyến thất bại');
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('Lỗi kết nối: $e');
    } finally {
      if (!mounted) return;
      setState(() => _isSearching = false);
    }
  }

  void _showSnackBar(String message, {bool isError = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Google Maps
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: _currentPosition != null
                  ? LatLng(_currentPosition!.latitude, _currentPosition!.longitude)
                  : const LatLng(21.0285, 105.8542), // Hanoi default
              zoom: 15,
            ),
            onMapCreated: (controller) {
              _mapController = controller;
            },
            markers: _markers,
            polylines: _polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
          ),

          // Top search bar
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 16,
            right: 16,
            child: _buildSearchBar(),
          ),

          // Bottom sheet
          if (_showVehicleSelection)
            _buildVehicleSelectionSheet(),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Back button and title
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => context.go('/user-home'),
                ),
                const Expanded(
                  child: Text(
                    'Bạn muốn đi đâu?',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Pickup address (current location)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: const BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Điểm đón',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        _pickupAddress,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.my_location, color: Colors.blue),
                  onPressed: _getCurrentLocation,
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Destination input
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _destinationController,
                    decoration: const InputDecoration(
                      hintText: 'Nhập điểm đến',
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                    onChanged: _searchPlaces,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.search, color: Colors.grey),
                  onPressed: () => _searchPlaces(_destinationController.text),
                ),
              ],
            ),
          ),

          // Search results
          if (_searchResults.isNotEmpty)
            Container(
              constraints: const BoxConstraints(maxHeight: 300),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: _searchResults.length,
                itemBuilder: (context, index) {
                  final result = _searchResults[index];
                  return ListTile(
                    leading: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(Icons.location_on, color: Colors.red.shade400),
                    ),
                    title: Text(
                      result['name'],
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                    subtitle: Text(
                      result['address'],
                      style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                    ),
                    onTap: () => _selectDestination(result),
                  );
                },
              ),
            ),

          if (_isSearching)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }

  Widget _buildVehicleSelectionSheet() {
    return DraggableScrollableSheet(
      initialChildSize: 0.5,
      minChildSize: 0.3,
      maxChildSize: 0.85,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              // Handle
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Route info
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    color: Colors.green,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _pickupAddress,
                                    style: const TextStyle(fontSize: 12),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    color: Colors.red,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _destinationAddress,
                                    style: const TextStyle(fontSize: 12),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      if (_distance != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '${_distance!.toStringAsFixed(1)} km',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Vehicle list
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: _vehicleCategories.length,
                  itemBuilder: (context, categoryIndex) {
                    final category = _vehicleCategories[categoryIndex];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Text(
                            category['category'],
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Colors.grey.shade700,
                            ),
                          ),
                        ),
                        ...List.generate(category['vehicles'].length, (vehicleIndex) {
                          int globalIndex = 0;
                          for (int i = 0; i < categoryIndex; i++) {
                            globalIndex += (_vehicleCategories[i]['vehicles'] as List).length;
                          }
                          globalIndex += vehicleIndex;

                          final vehicle = category['vehicles'][vehicleIndex];
                          final isSelected = _selectedVehicleIndex == globalIndex;
                          final price = _distance != null
                              ? ((_distance! * vehicle['pricePerKm']) + 10000).toInt()
                              : vehicle['basePrice'];

                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                _selectedVehicleIndex = globalIndex;
                                _calculatePrice();
                              });
                            },
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: isSelected ? Colors.blue.shade50 : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: isSelected ? Colors.blue : Colors.grey.shade200,
                                  width: isSelected ? 2 : 1,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Text(
                                    vehicle['icon'],
                                    style: const TextStyle(fontSize: 32),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          vehicle['name'],
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          vehicle['description'],
                                          style: TextStyle(
                                            color: Colors.grey.shade600,
                                            fontSize: 12,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            Icon(Icons.access_time, size: 12, color: Colors.grey.shade600),
                                            const SizedBox(width: 4),
                                            Text(
                                              vehicle['eta'],
                                              style: TextStyle(
                                                color: Colors.grey.shade600,
                                                fontSize: 12,
                                              ),
                                            ),
                                            const SizedBox(width: 12),
                                            Icon(Icons.person, size: 12, color: Colors.grey.shade600),
                                            const SizedBox(width: 4),
                                            Text(
                                              '${vehicle['capacity']}',
                                              style: TextStyle(
                                                color: Colors.grey.shade600,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        '${price.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}đ',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                        const SizedBox(height: 16),
                      ],
                    );
                  },
                ),
              ),

              // Book button
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isSearching ? null : _createBooking,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _isSearching
                        ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    )
                        : Text(
                      _estimatedPrice != null
                          ? 'Đặt xe - ${_estimatedPrice!.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}đ'
                          : 'Đặt xe',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}