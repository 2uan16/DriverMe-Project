import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'dart:convert';
import '../../config/app_config.dart';
import '../../services/auth_service.dart';

class EnhancedBookingScreen extends StatefulWidget {
  const EnhancedBookingScreen({super.key});

  @override
  State<EnhancedBookingScreen> createState() => _EnhancedBookingScreenState();
}

class _EnhancedBookingScreenState extends State<EnhancedBookingScreen>
    with SingleTickerProviderStateMixin {
  final AuthService _authService = AuthService();

  // Form controllers
  final _destinationController = TextEditingController();
  final _notesController = TextEditingController();

  // State variables
  String _currentLocation = "Vị trí hiện tại"; // Auto-detect user location
  String _selectedServiceType = 'standard';
  int _selectedVehicleType = 0;
  double? _estimatedPrice;
  bool _loading = false;
  bool _showVehicleOptions = false;
  List<Map<String, String>> _searchResults = [];

  // Vehicle categories
  final List<Map<String, dynamic>> _vehicleCategories = [
    {
      'category': 'Dòng xe phổ thông',
      'vehicles': [
        {
          'name': 'DriverMe Eco',
          'description': 'Tiết kiệm, thân thiện môi trường',
          'icon': '🚗',
          'basePrice': 12000,
          'eta': '3-5 phút',
          'capacity': 4,
          'color': Colors.green,
        },
        {
          'name': 'DriverMe',
          'description': 'Xe phổ thông 4 chỗ',
          'icon': '🚙',
          'basePrice': 15000,
          'eta': '2-4 phút',
          'capacity': 4,
          'color': Colors.blue,
        },
      ]
    },
    {
      'category': 'Dòng xe trung cấp',
      'vehicles': [
        {
          'name': 'DriverMe Plus',
          'description': 'Xe trung cấp, thoải mái hơn',
          'icon': '🚘',
          'basePrice': 20000,
          'eta': '3-6 phút',
          'capacity': 4,
          'color': Colors.orange,
        },
        {
          'name': 'DriverMe 7',
          'description': 'Xe 7 chỗ, phù hợp gia đình',
          'icon': '🚐',
          'basePrice': 25000,
          'eta': '4-7 phút',
          'capacity': 7,
          'color': Colors.purple,
        },
      ]
    },
    {
      'category': 'Dòng xe cao cấp/hạng sang',
      'vehicles': [
        {
          'name': 'DriverMe Premium',
          'description': 'Xe cao cấp, dịch vụ VIP',
          'icon': '🏎️',
          'basePrice': 35000,
          'eta': '5-10 phút',
          'capacity': 4,
          'color': Colors.amber,
        },
        {
          'name': 'DriverMe Luxury',
          'description': 'Xe hạng sang, phục vụ đẳng cấp',
          'icon': '🚗',
          'basePrice': 50000,
          'eta': '7-12 phút',
          'capacity': 4,
          'color': Colors.black,
        },
      ]
    },
    {
      'category': 'Dòng xe chuyên biệt',
      'vehicles': [
        {
          'name': 'DriverMe Bike',
          'description': 'Xe máy, di chuyển nhanh',
          'icon': '🏍️',
          'basePrice': 8000,
          'eta': '1-3 phút',
          'capacity': 2,
          'color': Colors.red,
        },
        {
          'name': 'DriverMe Truck',
          'description': 'Xe tải nhỏ, chở hàng',
          'icon': '🚚',
          'basePrice': 30000,
          'eta': '10-15 phút',
          'capacity': 3,
          'color': Colors.brown,
        },
      ]
    },
  ];

  // Mock saved addresses
  final List<Map<String, dynamic>> _savedAddresses = [
    {
      'name': 'Nhà',
      'address': 'Số 123, Đường ABC, Quận XYZ',
      'icon': Icons.home,
      'color': Colors.blue,
    },
    {
      'name': 'Công ty',
      'address': 'Tòa nhà DEF, Phố GHI, Quận JKL',
      'icon': Icons.business,
      'color': Colors.orange,
    },
    {
      'name': 'Trường học',
      'address': 'Đại học MNO, Đường PQR, Quận STU',
      'icon': Icons.school,
      'color': Colors.green,
    },
  ];

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  @override
  void dispose() {
    _destinationController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _getCurrentLocation() async {
    setState(() => _loading = true);

    try {
      // TODO: Implement actual location service
      await Future.delayed(const Duration(seconds: 1));
      setState(() {
        _currentLocation = "Vinhomes Smart City, Hà Nội";
      });
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _searchPlaces(String query) async {
    if (query.isEmpty) {
      setState(() => _searchResults = []);
      return;
    }

    setState(() => _loading = true);

    try {
      // TODO: Implement Google Places API
      await Future.delayed(const Duration(milliseconds: 500));

      // Mock search results
      setState(() {
        _searchResults = [
          {
            'name': '$query - Quận Ba Đình',
            'address': '$query, Quận Ba Đình, Hà Nội',
          },
          {
            'name': '$query - Quận Cầu Giấy',
            'address': '$query, Quận Cầu Giấy, Hà Nội',
          },
          {
            'name': '$query - Quận Đống Đa',
            'address': '$query, Quận Đống Đa, Hà Nội',
          },
        ];
      });
    } finally {
      setState(() => _loading = false);
    }
  }

  List<Map<String, dynamic>> _getAllVehicles() {
    List<Map<String, dynamic>> allVehicles = [];
    for (var category in _vehicleCategories) {
      allVehicles.addAll(category['vehicles']);
    }
    return allVehicles;
  }

  Future<void> _calculatePrice() async {
    if (_destinationController.text.isEmpty) return;

    setState(() => _loading = true);

    try {
      await Future.delayed(const Duration(milliseconds: 800));

      final vehicles = _getAllVehicles();
      final vehicle = vehicles[_selectedVehicleType];
      final basePrice = vehicle['basePrice'] as int;
      final distance = 5.2; // Mock distance in km

      final calculatedPrice = (basePrice * distance) + 10000; // + booking fee

      setState(() {
        _estimatedPrice = calculatedPrice;
        _showVehicleOptions = true;
      });
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _createBooking() async {
    if (!_authService.isLoggedIn) {
      _showSnackBar('Vui lòng đăng nhập để đặt chuyến');
      return;
    }

    setState(() => _loading = true);

    try {
      final vehicles = _getAllVehicles();
      final payload = {
        'pickup_address': _currentLocation,
        'destination_address': _destinationController.text.trim(),
        'service_type': 'point_to_point',
        'estimated_price': _estimatedPrice?.toInt(),
        'vehicle_type': vehicles[_selectedVehicleType]['name'],
        'notes': _notesController.text.trim(),
      };

      final res = await _authService.authenticatedRequest(
        method: 'POST',
        endpoint: AppConfig.bookingEndpoint,
        body: payload,
      );

      final data = json.decode(res.body);

      if (res.statusCode >= 200 && res.statusCode < 300 && data['success'] == true) {
        _showSnackBar(data['message'] ?? 'Đặt chuyến thành công!', isError: false);
        context.go('/bookings');
      } else {
        _showSnackBar(data['message'] ?? 'Đặt chuyến thất bại');
      }
    } catch (e) {
      _showSnackBar('Lỗi kết nối: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  void _showSnackBar(String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: Duration(seconds: isError ? 4 : 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Map Area
          Container(
            height: MediaQuery.of(context).size.height * 0.6,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.blue.shade100,
                  Colors.blue.shade300,
                ],
              ),
            ),
            child: Stack(
              children: [
                // Mock Google Maps
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.map, color: Colors.blue.shade600, size: 48),
                        const SizedBox(height: 12),
                        const Text(
                          'Google Maps',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text(
                          'Sẽ tích hợp ở đây',
                          style: TextStyle(fontSize: 14, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),

                // Top navigation
                Positioned(
                  top: MediaQuery.of(context).padding.top + 16,
                  left: 16,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => context.go('/user-home'),
                    ),
                  ),
                ),

                // Map controls
                Positioned(
                  top: MediaQuery.of(context).padding.top + 16,
                  right: 16,
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.my_location),
                          onPressed: _getCurrentLocation,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Bottom Sheet
          DraggableScrollableSheet(
            initialChildSize: 0.45,
            minChildSize: 0.4,
            maxChildSize: 0.85,
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Handle
                    Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),

                    Expanded(
                      child: ListView(
                        controller: scrollController,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        children: [
                          if (!_showVehicleOptions) ...[
                            _buildLocationInputSection(),
                          ] else ...[
                            _buildVehicleSelectionSection(),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLocationInputSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        const Text(
          'Bạn muốn đi đâu?',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 20),

        // Location inputs
        Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Column(
            children: [
              // Pickup location (auto-detected)
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Điểm đón',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(
                            _currentLocation,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.my_location, color: Colors.blue.shade600),
                      onPressed: _getCurrentLocation,
                    ),
                  ],
                ),
              ),

              // Divider line
              Container(
                margin: const EdgeInsets.only(left: 44),
                child: Divider(color: Colors.grey.shade300, height: 1),
              ),

              // Destination input
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextField(
                        controller: _destinationController,
                        decoration: const InputDecoration(
                          hintText: 'Nhập điểm đến',
                          hintStyle: TextStyle(color: Colors.grey),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.zero,
                        ),
                        style: const TextStyle(fontSize: 16),
                        onChanged: _searchPlaces,
                        onSubmitted: (_) => _calculatePrice(),
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.search, color: Colors.grey.shade600),
                      onPressed: () => _searchPlaces(_destinationController.text),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // Search results
        if (_searchResults.isNotEmpty) ...[
          const Text(
            'Kết quả tìm kiếm',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _searchResults.length,
            itemBuilder: (context, index) {
              final result = _searchResults[index];
              return ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.location_on, color: Colors.red.shade400),
                ),
                title: Text(
                  result['name']!,
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
                subtitle: Text(
                  result['address']!,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                onTap: () {
                  _destinationController.text = result['name']!;
                  setState(() => _searchResults = []);
                  _calculatePrice();
                },
              );
            },
          ),
          const SizedBox(height: 20),
        ],

        // Saved addresses
        if (_searchResults.isEmpty) ...[
          const Text(
            'Địa chỉ đã lưu',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: _savedAddresses.map((address) {
              return Expanded(
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  child: InkWell(
                    onTap: () {
                      _destinationController.text = address['address'];
                      _calculatePrice();
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: address['color'].withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: address['color'].withOpacity(0.3),
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            address['icon'],
                            color: address['color'],
                            size: 24,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            address['name'],
                            style: TextStyle(
                              color: address['color'],
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],

        const SizedBox(height: 100),
      ],
    );
  }

  Widget _buildVehicleSelectionSection() {
    final allVehicles = _getAllVehicles();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Route summary
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.blue.shade50,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _currentLocation,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _destinationController.text,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.edit, size: 20),
                onPressed: () {
                  setState(() {
                    _showVehicleOptions = false;
                    _searchResults = [];
                  });
                },
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        const Text(
          'Chọn loại xe',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 16),

        // Vehicle options by category
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _vehicleCategories.length,
          itemBuilder: (context, categoryIndex) {
            final category = _vehicleCategories[categoryIndex];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text(
                    category['category'],
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade700,
                    ),
                  ),
                ),
                ...List.generate(category['vehicles'].length, (vehicleIndex) {
                  // Calculate global index
                  int globalIndex = 0;
                  for (int i = 0; i < categoryIndex; i++) {
                    globalIndex += (_vehicleCategories[i]['vehicles'] as List).length;
                  }
                  globalIndex += vehicleIndex;

                  final vehicle = category['vehicles'][vehicleIndex];
                  final isSelected = _selectedVehicleType == globalIndex;
                  final price = _estimatedPrice != null
                      ? (_estimatedPrice! * (vehicle['basePrice'] / allVehicles[0]['basePrice'])).toInt()
                      : vehicle['basePrice'];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.blue.shade50 : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? Colors.blue : Colors.grey.shade200,
                        width: isSelected ? 2 : 1,
                      ),
                    ),
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _selectedVehicleType = globalIndex;
                        });
                      },
                      child: Row(
                        children: [
                          // Vehicle icon
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: vehicle['color'].withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(
                                vehicle['icon'],
                                style: const TextStyle(fontSize: 24),
                              ),
                            ),
                          ),

                          const SizedBox(width: 16),

                          // Vehicle info
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  vehicle['name'],
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  vehicle['description'],
                                  style: TextStyle(
                                    color: Colors.grey.shade600,
                                    fontSize: 12,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.access_time,
                                      size: 12,
                                      color: Colors.grey.shade600,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      vehicle['eta'],
                                      style: TextStyle(
                                        color: Colors.grey.shade600,
                                        fontSize: 12,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Icon(
                                      Icons.person,
                                      size: 12,
                                      color: Colors.grey.shade600,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${vehicle['capacity']}',
                                      style: TextStyle(
                                        color: Colors.grey.shade600,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                          // Price
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${price.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}đ',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 16),
              ],
            );
          },
        ),

        // Book button
        Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(vertical: 20),
          child: ElevatedButton(
            onPressed: _loading ? null : _createBooking,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: _loading
                ? const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 2,
              ),
            )
                : Text(
              'Đặt xe - ${_estimatedPrice != null ? "${_estimatedPrice!.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}đ" : "Tính giá"}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ),

        const SizedBox(height: 100),
      ],
    );
  }
}