import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;
import '../../config/app_config.dart';

class UserBookingsScreen extends StatefulWidget {
  const UserBookingsScreen({super.key});

  @override
  State<UserBookingsScreen> createState() => _UserBookingsScreenState();
}

class _UserBookingsScreenState extends State<UserBookingsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _loading = false;
  List<Map<String, dynamic>> _activeBookings = [];
  List<Map<String, dynamic>> _historyBookings = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadBookings();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadBookings() async {
    setState(() => _loading = true);
    try {
      final uri = Uri.parse(AppConfig.bookingEndpoint);
      final res = await http
          .get(uri)
          .timeout(Duration(seconds: AppConfig.requestTimeoutSeconds));

      if (!mounted) return;

      // Decode JSON safely
      final Object? decoded = _safeDecode(res.body);
      final ok = res.statusCode >= 200 && res.statusCode < 300;

      if (ok) {
        // Extract bookings list from decoded response
        final allBookings = _extractBookings(decoded);

        // Separate active and history bookings
        setState(() {
          _activeBookings = allBookings
              .where((b) => _isActiveStatus(b['status']?.toString() ?? ''))
              .toList();
          _historyBookings = allBookings
              .where((b) => !_isActiveStatus(b['status']?.toString() ?? ''))
              .toList();
        });
      } else {
        _showSnackBar('Không thể tải danh sách chuyến');
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('Lỗi kết nối: $e');
    } finally {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  // Check if booking status is active
  bool _isActiveStatus(String status) {
    return ['pending', 'accepted', 'in_progress'].contains(status.toLowerCase());
  }

  // Decode JSON safely
  Object? _safeDecode(String body) {
    try {
      return json.decode(body);
    } catch (_) {
      return null;
    }
  }

  // Extract bookings from various response formats
  List<Map<String, dynamic>> _extractBookings(Object? decoded) {
    // Case 1: { bookings: [...] }
    if (decoded is Map<String, dynamic>) {
      final bookings = decoded['bookings'];
      if (bookings is List) {
        return bookings
            .map<Map<String, dynamic>>((e) => (e as Map).cast<String, dynamic>())
            .toList();
      }
      // Case: { data: [...] }
      final data = decoded['data'];
      if (data is List) {
        return data
            .map<Map<String, dynamic>>((e) => (e as Map).cast<String, dynamic>())
            .toList();
      }
      // Case: { items: [...] }
      final items = decoded['items'];
      if (items is List) {
        return items
            .map<Map<String, dynamic>>((e) => (e as Map).cast<String, dynamic>())
            .toList();
      }
      return const [];
    }

    // Case 2: Direct List response
    if (decoded is List) {
      return decoded
          .map<Map<String, dynamic>>((e) => (e as Map).cast<String, dynamic>())
          .toList();
    }

    // Case 3: Invalid format
    return const [];
  }

  Future<void> _cancelBooking(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hủy chuyến'),
        content: const Text('Bạn có chắc muốn hủy chuyến này không?\nLưu ý: Có thể áp dụng phí hủy chuyến.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Không'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Hủy chuyến'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final uri = Uri.parse('${AppConfig.bookingEndpoint}/$id');
      final res = await http
          .delete(uri)
          .timeout(Duration(seconds: AppConfig.requestTimeoutSeconds));

      if (!mounted) return;

      Map<String, dynamic>? data;
      try {
        data = json.decode(res.body) as Map<String, dynamic>;
      } catch (_) {}

      final ok = res.statusCode >= 200 && res.statusCode < 300;
      final msg = (data?['message'] is String)
          ? data!['message'] as String
          : (ok ? 'Đã hủy chuyến thành công' : 'Hủy chuyến thất bại');

      _showSnackBar(msg, isError: !ok);
      if (ok) _loadBookings(); // Refresh list
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('Lỗi kết nối: $e');
    }
  }

  void _showSnackBar(String message, {bool isError = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: Duration(seconds: isError ? 4 : 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chuyến Đi Của Tôi'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/user-home'),
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              icon: const Icon(Icons.pending_actions),
              text: 'Đang diễn ra (${_activeBookings.length})',
            ),
            Tab(
              icon: const Icon(Icons.history),
              text: 'Lịch sử (${_historyBookings.length})',
            ),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
        controller: _tabController,
        children: [
          _buildBookingsList(_activeBookings, isActive: true),
          _buildBookingsList(_historyBookings, isActive: false),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/user/create-booking'),
        icon: const Icon(Icons.add),
        label: const Text('Đặt chuyến'),
      ),
    );
  }

  Widget _buildBookingsList(List<Map<String, dynamic>> bookings, {required bool isActive}) {
    if (bookings.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isActive ? Icons.search_off : Icons.history_toggle_off,
              size: 64,
              color: Colors.grey,
            ),
            const SizedBox(height: 16),
            Text(
              isActive
                  ? 'Không có chuyến nào đang diễn ra'
                  : 'Chưa có lịch sử chuyến đi',
              style: const TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => context.push('/user/create-booking'),
              child: const Text('Đặt chuyến ngay'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadBookings,
      child: ListView.builder(
        padding: const EdgeInsets.all(AppConfig.defaultPadding),
        itemCount: bookings.length,
        itemBuilder: (context, index) {
          final booking = bookings[index];
          return _buildBookingCard(booking, isActive: isActive);
        },
      ),
    );
  }

  Widget _buildBookingCard(Map<String, dynamic> booking, {required bool isActive}) {
    final id = (booking['id'] ?? booking['_id'] ?? '').toString();
    final pickup = (booking['pickup_address'] ?? '').toString();
    final destination = (booking['destination_address'] ?? '').toString();
    final price = (booking['price'] ?? booking['estimated_price'] ?? 0).toString();
    final status = (booking['status'] ?? '').toString();
    final serviceType = (booking['service_type'] ?? '').toString();
    final driverName = (booking['driver_name'] ?? '').toString();
    final driverPhone = (booking['driver_phone'] ?? '').toString();

    // Status styling
    Color statusColor = Colors.grey;
    IconData statusIcon = Icons.help;
    String statusText = '';

    switch (status.toLowerCase()) {
      case 'pending':
        statusColor = Colors.orange;
        statusIcon = Icons.pending;
        statusText = 'Đang tìm tài xế';
        break;
      case 'accepted':
        statusColor = Colors.blue;
        statusIcon = Icons.check_circle;
        statusText = 'Đã nhận chuyến';
        break;
      case 'in_progress':
        statusColor = Colors.green;
        statusIcon = Icons.directions_car;
        statusText = 'Đang thực hiện';
        break;
      case 'completed':
        statusColor = Colors.green;
        statusIcon = Icons.done_all;
        statusText = 'Hoàn thành';
        break;
      case 'cancelled':
        statusColor = Colors.red;
        statusIcon = Icons.cancel;
        statusText = 'Đã hủy';
        break;
      default:
        statusText = status.isNotEmpty ? status : 'Không xác định';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with status and ID
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(statusIcon, size: 16, color: statusColor),
                      const SizedBox(width: 4),
                      Text(
                        statusText,
                        style: TextStyle(
                          color: statusColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                if (id.isNotEmpty)
                  Text(
                    'ID: $id',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
              ],
            ),

            const SizedBox(height: 12),

            // Service type and locations
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  serviceType == 'hourly' ? Icons.access_time : Icons.location_on,
                  color: Colors.blue,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        serviceType == 'hourly'
                            ? 'Thuê theo giờ'
                            : 'Chuyến đi',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 4),
                      if (pickup.isNotEmpty)
                        Row(
                          children: [
                            const Icon(Icons.radio_button_checked, size: 12, color: Colors.green),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                pickup,
                                style: TextStyle(color: Colors.grey[700]),
                              ),
                            ),
                          ],
                        ),
                      if (destination.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.location_on, size: 12, color: Colors.red),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                destination,
                                style: TextStyle(color: Colors.grey[700]),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Driver info (if available)
            if (driverName.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.blue,
                      child: Icon(Icons.person, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            driverName,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          if (driverPhone.isNotEmpty)
                            Text(
                              driverPhone,
                              style: TextStyle(color: Colors.grey[600], fontSize: 12),
                            ),
                        ],
                      ),
                    ),
                    if (isActive && driverPhone.isNotEmpty)
                      IconButton(
                        onPressed: () {
                          // TODO: Implement phone call functionality
                          _showSnackBar('Tính năng gọi điện đang phát triển', isError: false);
                        },
                        icon: const Icon(Icons.phone, color: Colors.green),
                        tooltip: 'Gọi tài xế',
                      ),
                  ],
                ),
              ),

            const SizedBox(height: 12),

            // Price and additional info
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isActive ? 'Ước tính' : 'Tổng cộng',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        price.isNotEmpty ? '$price VNĐ' : 'Chưa có giá',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                ),
                if (!isActive && booking['rating'] != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.amber.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          '${booking['rating']}/5',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
              ],
            ),

            // Action buttons for active bookings
            if (isActive && id.isNotEmpty) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  if (status.toLowerCase() == 'pending' || status.toLowerCase() == 'accepted')
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _cancelBooking(id),
                        icon: const Icon(Icons.cancel, size: 16),
                        label: const Text('Hủy chuyến'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red,
                          side: const BorderSide(color: Colors.red),
                        ),
                      ),
                    ),
                  if (status.toLowerCase() == 'pending' || status.toLowerCase() == 'accepted')
                    const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        // TODO: Navigate to booking tracking screen
                        _showSnackBar('Tính năng theo dõi đang phát triển...', isError: false);
                      },
                      icon: const Icon(Icons.track_changes, size: 16),
                      label: const Text('Theo dõi'),
                    ),
                  ),
                ],
              ),
            ],

            // Show booking time
            if (booking['booking_time'] != null || booking['created_at'] != null) ...[
              const SizedBox(height: 8),
              Text(
                'Đặt lúc: ${booking['booking_time'] ?? booking['created_at'] ?? ''}',
                style: TextStyle(
                  color: Colors.grey[500],
                  fontSize: 11,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}