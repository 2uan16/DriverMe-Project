import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../config/app_config.dart';
import '../../services/auth_service.dart';

class PointToPointBookingScreen extends StatefulWidget {
  const PointToPointBookingScreen({super.key});

  @override
  State<PointToPointBookingScreen> createState() => _PointToPointBookingScreenState();
}

class _PointToPointBookingScreenState extends State<PointToPointBookingScreen> {
  final AuthService _authService = AuthService();
  final _formKey = GlobalKey<FormState>();
  final _pickupController = TextEditingController();
  final _destinationController = TextEditingController();
  final _notesController = TextEditingController();

  double? _estimatedPrice;
  bool _loading = false;

  @override
  void dispose() {
    _pickupController.dispose();
    _destinationController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _calculatePrice() async {
    if (_pickupController.text.trim().isEmpty || _destinationController.text.trim().isEmpty) return;

    setState(() => _loading = true);
    try {
      // Demo tính giá cơ bản; sau thay bằng API nếu cần
      await Future.delayed(const Duration(milliseconds: 500));
      const base = 150000.0;

      if (!mounted) return;
      setState(() => _estimatedPrice = base + 10000.0);
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('Không thể tính giá: $e');
    } finally {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  Future<void> _createBooking() async {
    if (!_formKey.currentState!.validate()) return;

    if (!_authService.isLoggedIn) {
      _showSnackBar('Vui lòng đăng nhập để đặt chuyến');
      context.go('/login-user');
      return;
    }

    setState(() => _loading = true);
    try {
      final payload = {
        'pickup_address': _pickupController.text.trim(),
        'destination_address': _destinationController.text.trim(),
        'service_type': 'point_to_point',
        'estimated_price': _estimatedPrice,
        'notes': _notesController.text.trim(),
      };

      final res = await _authService.authenticatedRequest(
        method: 'POST',
        endpoint: AppConfig.bookingEndpoint,
        body: payload,
      );

      if (!mounted) return;

      Map<String, dynamic>? data;
      try {
        data = json.decode(res.body) as Map<String, dynamic>;
      } catch (_) {}

      final ok = res.statusCode >= 200 && res.statusCode < 300;
      final success = data?['success'] == true || (ok && data == null);
      final msg = (data?['message'] is String)
          ? data!['message'] as String
          : (ok ? 'Đặt chuyến thành công!' : 'Đặt chuyến thất bại');

      if (ok && success) {
        _showSnackBar(msg, isError: false);

        // Clear form
        _pickupController.clear();
        _destinationController.clear();
        _notesController.clear();
        setState(() => _estimatedPrice = null);

        // Navigate to bookings list after short delay
        await Future.delayed(const Duration(milliseconds: 1000));
        if (!mounted) return;
        context.go('/user-home');
      } else {
        _showSnackBar(msg);
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('Lỗi kết nối: $e');
    } finally {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  void _showSnackBar(String message, {bool isError = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: Duration(seconds: isError ? 4 : 2),
      ),
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icon),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
      borderSide: const BorderSide(color: Color(0xFF2E7D32), width: 2),
    ),
    filled: true,
    fillColor: Colors.grey[50],
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Đặt Chuyến Điểm - Điểm'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/user-home'),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppConfig.defaultPadding),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Service Type Info Card
                Card(
                  color: Colors.blue[50],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        const Icon(Icons.directions_car, color: Colors.blue, size: 32),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Chuyến Điểm - Điểm',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Tài xế sẽ đưa bạn từ điểm đón đến điểm đến',
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Location Information Card
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Thông Tin Địa Điểm',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 16),

                        // Pickup Location
                        TextFormField(
                          controller: _pickupController,
                          textInputAction: TextInputAction.next,
                          decoration: _inputDecoration('Điểm Đón *', Icons.my_location),
                          validator: (v) => (v == null || v.trim().isEmpty)
                              ? 'Vui lòng nhập điểm đón'
                              : null,
                          onChanged: (_) => _calculatePrice(),
                        ),

                        const SizedBox(height: 16),

                        // Destination
                        TextFormField(
                          controller: _destinationController,
                          textInputAction: TextInputAction.next,
                          decoration: _inputDecoration('Điểm Đến *', Icons.location_on),
                          validator: (v) => (v == null || v.trim().isEmpty)
                              ? 'Vui lòng nhập điểm đến'
                              : null,
                          onChanged: (_) => _calculatePrice(),
                        ),

                        const SizedBox(height: 16),

                        // Notes
                        TextFormField(
                          controller: _notesController,
                          maxLines: 3,
                          decoration: _inputDecoration(
                            'Ghi chú cho tài xế (tùy chọn)',
                            Icons.note_add,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Price Estimation Card
                if (_estimatedPrice != null)
                  Card(
                    color: Colors.green[50],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.attach_money, color: Colors.green),
                              const SizedBox(width: 8),
                              const Text(
                                'Ước Tính Giá',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${_estimatedPrice!.toStringAsFixed(0)} VNĐ',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Giá cơ bản 150,000 VNĐ + phí đặt chuyến',
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 24),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _loading ? null : _calculatePrice,
                        child: _loading
                            ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                            : const Text('Tính Giá'),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      flex: 2,
                      child: ElevatedButton(
                        onPressed: (_loading || _estimatedPrice == null) ? null : _createBooking,
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size.fromHeight(AppConfig.buttonHeight),
                        ),
                        child: _loading
                            ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                            : const Text('Đặt Chuyến'),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // Information Card
                Card(
                  color: Colors.blue[50],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppConfig.defaultBorderRadius),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.info, color: Colors.blue),
                            const SizedBox(width: 8),
                            const Text(
                              'Lưu Ý',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        const Text('• Tài xế sẽ liên hệ với bạn trong vòng 5 phút'),
                        const Text('• Bạn có thể hủy miễn phí trong 10 phút đầu'),
                        const Text('• Thanh toán bằng tiền mặt hoặc chuyển khoản'),
                        const Text('• Đánh giá tài xế sau khi hoàn thành chuyến'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}