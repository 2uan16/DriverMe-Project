enum TripStatus {
  dangTim,  
  daNhan,
  daToiNoi,
  dangTrenDuong,
  daHoanThanh,
  daDanhGia
}