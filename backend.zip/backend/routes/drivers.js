const express = require('express');
const router = express.Router();

// Placeholder routes - sẽ implement sau
router.get('/available', (req, res) => {
  res.json({ success: true, message: 'Driver routes working' });
});

module.exports = router;